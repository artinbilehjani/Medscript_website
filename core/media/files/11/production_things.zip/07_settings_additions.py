"""
07_settings_additions.py — changes to add to your existing settings.py.

These are ADDITIONS/CHANGES, not a full settings file. Find the
matching section in your current settings.py and update accordingly.
"""

import os
from urllib.parse import urlparse

# ═══════════════════════════════════════════════════════════════════
# 1. Read everything from environment, not hardcoded
# ═══════════════════════════════════════════════════════════════════
# Your current dev compose already passes SECRET_KEY/DEBUG as env vars —
# good instinct. Just make sure settings.py actually reads them:

SECRET_KEY = os.environ.get("SECRET_KEY")
DEBUG = os.environ.get("DEBUG", "False") == "True"

ALLOWED_HOSTS = os.environ.get("DJANGO_ALLOWED_HOSTS", "").split(",")
# In prod .env: DJANGO_ALLOWED_HOSTS=yourdomain.com,www.yourdomain.com
# In dev compose: DJANGO_ALLOWED_HOSTS=*


# ═══════════════════════════════════════════════════════════════════
# 2. Database — Postgres via DATABASE_URL, not SQLite
# ═══════════════════════════════════════════════════════════════════
# Parse the DATABASE_URL env var both compose files now set. You can
# use dj-database-url for this (pip install dj-database-url) or do it
# manually — manual version shown so you don't need another dependency:

_db_url = urlparse(os.environ.get("DATABASE_URL", ""))

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": _db_url.path.lstrip("/"),
        "USER": _db_url.username,
        "PASSWORD": _db_url.password,
        "HOST": _db_url.hostname,
        "PORT": _db_url.port or 5432,
        # Keeps a small pool of DB connections alive between requests
        # instead of reconnecting every time — meaningful win under
        # concurrent load on a weak box.
        "CONN_MAX_AGE": 60,
    }
}


# ═══════════════════════════════════════════════════════════════════
# 3. Static files via Whitenoise (dev) / nginx (prod)
# ═══════════════════════════════════════════════════════════════════
# Whitenoise lets Django serve static files reasonably even without
# nginx (useful for `runserver` in dev where nginx isn't in the picture).
# In prod, nginx intercepts /static/ before Django ever sees it (see
# 05_nginx.conf) — whitenoise becomes a harmless no-op fallback there.

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",   # ← add right after SecurityMiddleware
    # ...your existing middleware...
]

STATIC_URL = "/static/"
STATIC_ROOT = "/app/staticfiles"   # must match the volume mount in docker-compose.prod.yml
STATICFILES_STORAGE = "whitenoise.storage.CompressedManifestStaticFilesStorage"

MEDIA_URL = "/media/"
MEDIA_ROOT = "/app/media"   # must match the volume mount in docker-compose.prod.yml


# ═══════════════════════════════════════════════════════════════════
# 4. X-Accel-Redirect support for protected file downloads
# ═══════════════════════════════════════════════════════════════════
# See 08_file_download_views.py for the full pattern. This setting
# just defines the internal path prefix nginx is configured to
# recognize (matches the `location /protected-media/` block in
# 05_nginx.conf).

PROTECTED_MEDIA_URL = "/protected-media/"


# ═══════════════════════════════════════════════════════════════════
# 5. Rate limiting (django-ratelimit) — belt-and-suspenders with nginx
# ═══════════════════════════════════════════════════════════════════
# nginx rate limiting (05_nginx.conf) is your PRIMARY defense — it
# rejects excess requests before they even reach Django/Gunicorn,
# which is what actually protects a weak VPS. django-ratelimit adds a
# second, Django-level check that's useful for per-USER (not just
# per-IP) limits — e.g. stopping one logged-in student from hammering
# downloads even if they're behind a shared IP (university wifi/NAT,
# very plausible for a med school). See 08_file_download_views.py for
# usage. No settings changes needed beyond having it in
# 01_requirements.txt and INSTALLED_APPS is NOT required for it to work.


# ═══════════════════════════════════════════════════════════════════
# 6. Security headers — cheap, do these regardless of host strength
# ═══════════════════════════════════════════════════════════════════
if not DEBUG:
    SECURE_SSL_REDIRECT = True
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
    # The X-Forwarded-Proto header above only works correctly because
    # nginx sets it in 05_nginx.conf's `proxy_set_header` — without
    # that, Django would think every request is insecure HTTP forever
    # and you'd get infinite redirect loops.

# MedScript Infrastructure — Read This First

This bundle gives you a working **development** and **production** Docker setup,
plus the file-download hardening you asked about. Files are numbered in the
order you should read/use them.

## What's in this bundle

| File | What it's for |
|---|---|
| `01_requirements.txt` | Python dependencies — production WSGI server, Postgres driver, Pillow, bleach, etc. |
| `02_Dockerfile` | Single Dockerfile used by BOTH dev and prod (multi-purpose, controlled by compose `command:`) |
| `03_docker-compose.dev.yml` | Your development setup — Django runserver, hot reload, SQLite-free (Postgres), debug on |
| `04_docker-compose.prod.yml` | Production setup — Nginx + Gunicorn + Postgres, no debug, file download hardening built in |
| `05_nginx.conf` | Nginx config — this is what actually protects you on launch day |
| `06_gunicorn.conf.py` | Gunicorn worker tuning for a 1-2 core / 2-4GB VPS |
| `07_settings_additions.py` | Django settings changes needed (env-driven, X-Accel-Redirect, throttling) |
| `08_file_download_views.py` | Hardened PostFile download view (rate-limited, X-Accel-Redirect, no Celery needed) |
| `09_env_example` | `.env.prod` template — copy and fill in real secrets, never commit it |
| `10_EXPLANATIONS.md` | **The actual advice** — what every piece does, why, bare minimum vs recommended, answers to your Redis/Celery/zip/buffering questions |

## TL;DR — what to do, in order

1. Read `10_EXPLANATIONS.md` (this is the actual answer to your questions — start here if you want the reasoning before the files)
2. Use `03_docker-compose.dev.yml` locally — replace your current dev compose
3. Before launch, set up `04_docker-compose.prod.yml` on the VPS with `09_env_example` filled in
4. Apply `07_settings_additions.py` to your Django `settings.py`
5. Swap your file download view for `08_file_download_views.py`'s pattern
6. Do NOT add Celery/Redis for launch — see explanation for why

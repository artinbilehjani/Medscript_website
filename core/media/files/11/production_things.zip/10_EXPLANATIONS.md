# Explanations — what everything does, and direct answers to your questions

This is written for someone building their first production website. No
assumed knowledge. Read top to bottom once, then use the files as reference.

---

## 1. The big picture: what was actually dangerous

`python3 manage.py runserver 0.0.0.0:8000`, directly exposed to the internet
with no Nginx in front, is **the development server**. It exists so you can
code locally and see changes instantly. It is not built to handle more than
one or two people at a time reliably, has no real worker pool, and serves
files inefficiently. This — not file downloads specifically — was the
biggest risk to your launch.

The fix is the standard production stack:

```
Internet → Nginx (port 80/443) → Gunicorn (internal) → Django
```

- **Nginx**: a reverse proxy. Extremely lightweight, handles thousands of
  simultaneous connections on minimal RAM because it's event-driven (not
  one-process-per-request like Django). Its job: serve static/media files
  directly, rate-limit abusive traffic, and forward real page/API requests
  to Gunicorn.
- **Gunicorn**: a production WSGI server for Django. Runs a small, fixed
  pool of Python worker processes, each capable of handling one request at
  a time. This replaces `runserver`.
- **Django**: your actual application code, unchanged.

This is "the bare minimum" for any real Django deployment, regardless of
host strength. A weak VPS makes getting this right *more* important, not
optional.

---

## 2. Postgres vs SQLite — why Postgres won

You'd heard SQLite is "more practical for weak hosts." That's true for some
use cases (a single-writer blog, a read-mostly site) but not yours:

- SQLite locks the **whole database file** on every write. Your site has
  comments, reactions (likes/dislikes), and hit-counting — all writes,
  potentially concurrent. Under load, writes start queuing/failing.
- Postgres handles concurrent writes via row-level locking — built for
  exactly this.
- Postgres's resource cost on a 2-4GB box is trivial (~30-50MB idle). It is
  not competing meaningfully with Gunicorn/nginx for your limited RAM.

Your existing `docker-compose.yml` already had a Postgres service defined —
you were one `DATABASES` setting away from using it. `09_env_example` +
`07_settings_additions.py` wire it up via environment variables instead of
hardcoded values, which is also just better practice (same image works in
dev and prod, only the `.env` differs).

One bug I fixed silently in `03_docker-compose.dev.yml`: your original had
`./postgre/data:/var/lib/postgresql` (missing `/data` at the end) — Postgres
expects its data directory at `/var/lib/postgresql/data` specifically.

---

## 3. Your actual questions, answered directly

### "Does Redis/Celery help here?"

**Not for launch. Skip them.** Here's the reasoning, not just the verdict:

Celery + Redis solve **background task** problems — "do this slow thing
later, off the request/response cycle" (e.g. send a batch of emails,
process a video, generate a report). Your file downloads are not a
background-task problem: a user clicks download, they want the file *now*,
streamed directly to them. There's nothing to defer.

Adding Celery+Redis when you don't need them costs you:
- Two more containers running 24/7, each with baseline RAM (~30-50MB+ for
  Redis, ~80-150MB+ per Celery worker) — real cost on a 2-4GB box.
- More things that can break independently (Redis connection drops, Celery
  worker dies silently, task queue backs up) — more failure surface on a
  launch day where you want fewer moving parts, not more.
- Genuine added complexity for a junior/first-time developer to operate
  and debug under pressure.

**When would you actually need them?** If you later add: bulk file zipping
for "download all 20 files in this course" (see next answer), bulk email
notifications, scheduled tasks (e.g. nightly cleanup), or any "click button,
wait, then get notified when ready" flow. None of that is true today.

### "Does zip/compressing work? Note: user should get the ready file."

You said you want the **ready file**, not a "please wait, we're generating
your zip" flow — that's the right call for launch, and it simplifies things:

- **Don't zip multiple files together** unless a single download action
  genuinely needs to bundle multiple files (e.g. "download all session
  materials" as one click). If each `PostFile` is downloaded individually
  (which your current model/UI suggests — each file has its own download
  button), there's nothing to zip. Zipping only makes sense when combining
  *multiple* files into *one* download action.
- **Don't compress individual files for transfer** (e.g. gzipping a PDF on
  the fly). PDFs, images, and Office docs are already compressed internal
  formats — re-compressing them wastes CPU for ~0% size reduction. Nginx
  can gzip text-based responses (HTML/CSS/JS) automatically and cheaply,
  but that's irrelevant to PostFile downloads.
- **If you DO eventually need "download all files as one zip"**: that's
  the one legitimate Celery use case from your list. The pattern: user
  clicks "Download All" → Celery task zips the files in the background →
  user gets a "your zip is ready" notification/link once done. This is a
  genuine background-task problem (zipping 10 large files takes real time,
  shouldn't block a request). Build this only when you actually have that
  feature requested — not preemptively.

For now: each file is requested and streamed individually, on demand,
exactly as-is. `08_file_download_views.py` implements this correctly.

### "Should I add a buffer that delays requests at peak times, or show 'try again in a few moments'?"

**Yes, and you don't need to build this yourself** — Nginx's rate limiting
(`limit_req_zone` in `05_nginx.conf`) does exactly this, for free, before
any request even reaches Django:

- Per-IP limit on download requests: 2/second, small burst allowance, then
  automatic `503 "Server is busy, please try again in a few moments"`.
- Per-IP limit on simultaneous active downloads: max 3 at once
  (`limit_conn`) — catches someone with 10 tabs open all downloading
  slowly.
- General page/API traffic gets a separate, more generous limit (10/s) so
  download-specific limits don't accidentally throttle normal browsing.

This is the "buffer" you were describing — implemented at the cheapest
possible layer (nginx, before Django/Gunicorn/Postgres are touched at all),
which is exactly right for a weak VPS: reject/delay excess load as early as
possible, before it costs you any real CPU/RAM.

---

## 4. Why X-Accel-Redirect matters (the single biggest lever)

This is the one piece of `08_file_download_views.py` worth understanding
deeply, because it's doing the actual heavy lifting:

**Without it** (typical naive Django download view): Django opens the file,
streams its bytes through the HTTP response, byte by byte, for the entire
download duration. If a student is on slow wifi downloading a 50MB lecture
PDF, **that Gunicorn worker is occupied for the whole transfer** — could be
10+ seconds, sometimes much longer. With only 2-3 total workers on your box,
just 2-3 simultaneous slow downloads can make your *entire site*
unresponsive for everyone else, including people just trying to load the
homepage.

**With X-Accel-Redirect**: Django's view does its job (check auth, check
`is_downloadable`, log the download if you want) and returns instantly —
microseconds, not seconds — with a special header telling **nginx** "you
serve this file from this internal path." Nginx then takes over the actual
byte-streaming, which it's built to do efficiently for thousands of
concurrent connections on minimal resources. The Gunicorn worker is freed
immediately and can serve the next request.

This single change is worth more to your launch-day stability than
Redis+Celery+rate-limiting combined, because it fixes the root cause
(workers held hostage by slow transfers) rather than just limiting how much
damage that root cause can do.

It also gives you a real enforcement mechanism for `is_downloadable=False`:
nginx's `location /protected-media/ { internal; }` block can ONLY be
reached via the `X-Accel-Redirect` header from Django — never directly by
URL guessing — so the flag genuinely blocks access rather than just hiding
a frontend button.

---

## 5. Bare minimum vs. recommended — what to actually do before launch

**Bare minimum (do this, non-negotiable):**
1. Nginx + Gunicorn in front of Django (`04_docker-compose.prod.yml`)
2. Postgres instead of SQLite (already in your compose, just wire it up)
3. `DEBUG=False` in production (`07_settings_additions.py`)
4. Nginx serving `/static/` and `/media/` directly (in `05_nginx.conf`)
5. A real, random `SECRET_KEY` (not `"test"`) — generate one as shown in
   `09_env_example`

**Strongly recommended (cheap, high value):**
6. X-Accel-Redirect for downloads (`08_file_download_views.py`) — protects
   you specifically against the "many people download big files at once"
   scenario you're worried about.
7. Nginx rate limiting (already in `05_nginx.conf`) — your "buffer"/"try
   again" mechanism, free.
8. Resource limits per container in compose (`deploy.resources.limits`,
   already set in `04_docker-compose.prod.yml`) — prevents one runaway
   container from starving the others and crashing the whole box.

**Not needed yet (skip until you have a concrete reason):**
9. Redis/Celery — no background-task need exists yet.
10. CDN / S3 — local disk + nginx is fine at your current scale (400 users,
    not-concurrent-by-design). Revisit if storage outgrows the VPS disk or
    you add a "download all as zip" feature.
11. Horizontal scaling / load balancing — you have one VPS; this is a
    multi-server concern.

---

## 6. What to do with this bundle, step by step

1. Put `02_Dockerfile`, `01_requirements.txt`, `03_docker-compose.dev.yml`,
   `04_docker-compose.prod.yml`, `05_nginx.conf`, `06_gunicorn.conf.py` in
   your project root (alongside your existing `core/` folder).
2. Apply the changes from `07_settings_additions.py` into your real
   `core/settings.py` (or wherever your settings module lives).
3. Replace your `mediafiles` app's download view with the pattern in
   `08_file_download_views.py`, update `urls.py` to match.
4. For local dev: `docker compose -f 03_docker-compose.dev.yml up --build`
5. For the VPS, before first deploy:
   - Copy `09_env_example` to `.env.prod`, fill in real values
   - Edit `05_nginx.conf`, replace `YOUR_DOMAIN_HERE`
   - `docker compose --env-file .env.prod -f 04_docker-compose.prod.yml up -d --build`
   - Run migrations: `docker compose -f 04_docker-compose.prod.yml exec backend python manage.py migrate`
   - Collect static files: `docker compose -f 04_docker-compose.prod.yml exec backend python manage.py collectstatic --noinput`
6. HTTPS: once your domain's DNS points at the VPS, ask me for the certbot
   + nginx HTTPS addition — it's a small, separate step that needs your
   real domain name to set up correctly.
